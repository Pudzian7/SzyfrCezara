﻿using System;
using System.ComponentModel;

namespace Szyfr_Cezara
{
    class SzyfrCezara : INotifyPropertyChanged
    {
        private bool czySzyfrowanie;
        private int klucz;
        private string tekst = string.Empty;
        private string wynik = string.Empty;

        public event PropertyChangedEventHandler? PropertyChanged;

        public void checkPropertyChangeEvent(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public SzyfrCezara()
        {
            CzySzyfrowanie = true;
            Klucz = 0;
            Tekst= "Ala ma kota";
            Wynik= string.Empty;
        }
        public bool CzySzyfrowanie
        {
            get { return czySzyfrowanie; }
            set
            {
                czySzyfrowanie = value;
                checkPropertyChangeEvent("CzySzyfrowanie");
            }
        }


        public int Klucz
        {
            get { return klucz; }
            set
            {
                klucz = value;
                checkPropertyChangeEvent("Klucz");
            }
        }

        public string Tekst
        {
            get { return tekst; }
            set
            {
                tekst = value;
                checkPropertyChangeEvent("Tekst");
            }
        }

        public string Wynik
        {
            get { return wynik; }
            set
            {
                wynik = value;
                checkPropertyChangeEvent("Wynik");
            }
        }

        public void Szyfruj()
        {
            if (!string.IsNullOrEmpty(Tekst) && Klucz >= 0)
            {
                char[] tekstArr = Tekst.ToCharArray();

                for (int i = 0; i < tekstArr.Length; i++)
                {
                    char znak = tekstArr[i];
                    if (Char.IsLetter(znak))
                    {
                        char poczatek = Char.IsLower(znak) ? 'a' : 'A';
                        if (CzySzyfrowanie)
                        {
                            tekstArr[i] = (char)(((znak - poczatek + Klucz) % 26) + poczatek);
                        }
                        else
                        {
                            tekstArr[i] = (char)(((znak - poczatek - Klucz + 26) % 26) + poczatek);
                        }
                    }
                }

                Wynik = new string(tekstArr);
            }
        }
    }
}
